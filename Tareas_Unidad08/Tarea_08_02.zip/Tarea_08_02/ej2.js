document.onkeydown = function(e){

    if (e.altKey && e.keyCode == 123) {

        document.body.style.backgroundImage = "url('./142.jpeg')";
        
    }
}